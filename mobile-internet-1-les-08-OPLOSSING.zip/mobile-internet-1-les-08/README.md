# Opdrachten voor Mobile & Internet 1, les 8

Deze les gaat over het derde hoofdstuk van CSS: 

- [CSS Layout](https://rogiervdl.github.io/CSS-course/03_layout.html#/)

Zie vooral dat je de onderdelen CSS Float en CSS Flexbox begrijpt; dit zullen we hier nodig hebben.
Het is tevens een herhaling van de vorige hoofdstukken. De opgave loopt over minstens twee lessen.

Begin bij **les08 opgave.pdf**