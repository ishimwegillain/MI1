# Opdrachten voor Mobile & Internet 1, les 7 

Deze les gaat over het tweede hoofdstuk van CSS: 

- [CSS Design](https://rogiervdl.github.io/CSS-course/02_design.html#/)

Begin bij **les07 opgave.pdf**