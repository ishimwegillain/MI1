# Opdrachten voor Mobile & Internet 1, les 9-12

Deze les gaat over de laatste hoofdstukken van CSS: 

- [CSS Layout](https://rogiervdl.github.io/CSS-course/03_layout.html#/)
- [CSS Responsive & Beyond](https://rogiervdl.github.io/CSS-course/04_responsive_beyond.html#/) (verschijnt binnenkort)

Zie bij layout vooral dat je de onderdelen CSS Float en CSS Flexbox begrijpt; dit zullen we hier nodig hebben.
Het is tevens een herhaling van de vorige hoofdstukken. De opgave loopt tot het einde van het semester.

Begin bij **les09-12 opgave.pdf**