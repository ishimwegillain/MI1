# Opdrachten voor Mobile & Internet 1, les 4 

Deze les gaat over alle geziene hoofdstukken, plus dit hoofdstuk: 

- [Formulieren](https://rogiervdl.github.io/HTML-course/07_forms.html#/)

Je zou de basis HTML onder de knie moeten hebben. Je leert nu de overige elementen kennen die in de vorige les nog niet aan bod gekomen zijn, waaronder dus formulieren.

Voor wie ruimte over heeft, zijn er een paar extra’s voorzien: Youtube filmpje embedden (staat op [https://www.youtube.com/watch?v=VGUkNtcB-jE](https://www.youtube.com/watch?v=VGUkNtcB-jE)), shortcut icon, email link, interne link (anchor)...

Begin bij **les04 opgave.pdf**